# de.medizininformatikinitiative.kerndatensatz.symptom#2027.0.0-ballot.rc1: MII IG Symptom(de)

## Pages

* [Startseite](index.md)
* [Beispiele](examples.md)
* [Versionierung](version-history.md)
* [Anleitung für Implementierende](implementer-guidance.md)
* [Profile](profiles.md)
* [Artefaktübersicht](artifacts.md)
* [Hinweise zur Übersetzung](translationinfo.md)
* [Änderungshistorie](changes.md)
* [Logische Modelle](logical-models.md)
* [Anleitung](guidance.md)
* [Downloads](downloads.md)
* [Sicherheit und Datenschutz](security-and-privacy.md)
* [CapabilityStatements](capability-statements.md)
* [UML-Diagramme](uml-diagrams.md)

## Resources

### Logicals

* [MII LM Symptom](StructureDefinition-mii-lm-symptom.md)

### Resource Profiles

* [MII_PR_Symptom_Condition](StructureDefinition-mii-pr-symptom-condition.md)
* [MII_PR_Symptom_Observation](StructureDefinition-mii-pr-symptom-observation.md)

### CapabilityStatements

* [MII CPS Symptom CapabilityStatement](CapabilityStatement-mii-cps-symptom-capabilitystatement.md)

### ImplementationGuides

* [MII IG Symptom](ImplementationGuide-mii-ig-symptom.md)

### Parameters

* [mii-param-symptom-manifest](Parameters-mii-param-symptom-manifest.md)

### Examples

* [mii-exa-symptom-vitreoretinochoroidopathy (Condition)](Condition-mii-exa-symptom-vitreoretinochoroidopathy.md)
* [mii-exa-symptom-arachnodactyly (Observation)](Observation-mii-exa-symptom-arachnodactyly.md)
* [mii-exa-symptom-chestpain (Observation)](Observation-mii-exa-symptom-chestpain.md)
