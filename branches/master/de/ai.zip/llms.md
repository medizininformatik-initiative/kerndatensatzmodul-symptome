# de.medizininformatikinitiative.kerndatensatz.symptom#2027.0.0-ballot: MII IG Symptom(de)

## Pages

* [Startseite](index.md)
* [Beispiele](examples.md)
* [Profile](profiles.md)
* [UML-Diagramme](uml-diagrams.md)
* [Hinweise zur Übersetzung](translationinfo.md)
* [CapabilityStatements](capability-statements.md)
* [Artefaktübersicht](artifacts.md)
* [Anleitung für Implementierende](implementer-guidance.md)
* [Anleitung](guidance.md)
* [Versionierung](version-history.md)
* [Sicherheit und Datenschutz](security-and-privacy.md)
* [Änderungshistorie](changes.md)
* [Logische Modelle](logical-models.md)
* [Downloads](downloads.md)

## Resources

### Logicals

* [MII LM Symptom](StructureDefinition-mii-lm-symptom.md)

### Resource Profiles

* [MII_PR_Symptom_Condition](StructureDefinition-mii-pr-symptom-condition.md)
* [MII_PR_Symptom_Observation](StructureDefinition-mii-pr-symptom-observation.md)

### CapabilityStatements

* [MII CPS Symptom CapabilityStatement](CapabilityStatement-mii-cps-symptom-capabilitystatement.md)

### ImplementationGuides

* [MII IG Symptom](ImplementationGuide-mii-ig-symptom.md)

### Parameters

* [mii-param-symptom-manifest](Parameters-mii-param-symptom-manifest.md)

### Examples

* [mii-exa-symptom-vitreoretinochoroidopathy (Condition)](Condition-mii-exa-symptom-vitreoretinochoroidopathy.md)
* [mii-exa-symptom-arachnodactyly (Observation)](Observation-mii-exa-symptom-arachnodactyly.md)
* [mii-exa-symptom-chestpain (Observation)](Observation-mii-exa-symptom-chestpain.md)
* [example-patient (Patient)](Patient-example-patient.md)
* [example (Patient)](Patient-example.md)
