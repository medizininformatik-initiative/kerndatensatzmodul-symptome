# Beispiel-Patientin (synthetisch) - MII IG Symptom v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Beispiel-Patientin (synthetisch)**

## Beispiel Patient: Beispiel-Patientin (synthetisch)

-------

**German**

-------

Erika Musterfrau-Testpatientin (no stated gender), DoB: 1970-01-01

-------



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "example-patient",
  "name" : [{
    "family" : "Musterfrau-Testpatientin",
    "given" : ["Erika"]
  }],
  "birthDate" : "1970-01-01"
}

```
