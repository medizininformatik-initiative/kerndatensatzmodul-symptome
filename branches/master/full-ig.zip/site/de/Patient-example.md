# Beispiel-Patient (synthetisch) - MII IG Symptom v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Beispiel-Patient (synthetisch)**

## Beispiel Patient: Beispiel-Patient (synthetisch)

-------

**German**

-------

Max Mustermann-Testpatient (no stated gender), DoB: 1970-01-01

-------



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "example",
  "name" : [{
    "family" : "Mustermann-Testpatient",
    "given" : ["Max"]
  }],
  "birthDate" : "1970-01-01"
}

```
